<?php

namespace ReclamationBundle\Entity;

use ReclamationBundle\Entity\Etudiant;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Normalizer\NormalizableInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

/**
 * Reclamation
 *
 * @ORM\Table(name="message_reclam")
 * @ORM\Entity(repositoryClass="ReclamationBundle\Repository\ReclamationRepository")
 */
class Reclamation implements \JsonSerializable
{

    private static $reclamationEtat = [
        "0" =>
            ["type" => "crée", "color" => "bg-warning"],
        "1" =>
            ["type" => "en cours de traitement", "color" => "bg-info"],
        "2" =>
            ["type" => "résolu", "color" => "bg-success"],
        "3" =>
            ["type" => "non résolu", "color" => "bg-danger"]
    ];


    /**
     * @var Etudiant
     * reclamation belongs to one user
     * @ORM\ManyToOne(targetEntity="ReclamationBundle\Entity\Etudiant", inversedBy="reclamations")
     */
    private $etudiant;

    public function __construct()
    {
        $this->dateCreation = new \DateTime("now");
        //if($this->container->get('security.token_storage')->getToken()->getUser())
    }

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * 0 = prof
     * 1 = note
     * @ORM\Column(type="smallint", options={0,1}, nullable=true)
     */
    private $id_reclamation;


    /**
     * @ORM\Column(type="text", nullable=false)
     */
    public $sujet;
    /**
     * @ORM\Column(type="text", nullable=false)
     */
    public $message;



    /**
     * @ORM\Column(type="date", name="date")
     */
    private $dateCreation;



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return \string[][]
     */
    public static function getReclamationEtat()
    {
        return self::$reclamationEtat;
    }



    /**
     * @return mixed
     */
    public function getIdReclamation()
    {
        return $this->id_reclamation;
    }

    /**
     * @param mixed $id_reclamation
     */
    public function setIdReclamation($id_reclamation)
    {
        $this->id_reclamation = $id_reclamation;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param mixed $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }



    /**
     * @return mixed
     */
    public function getEtudiant()
    {
        return $this->etudiant;
    }

    /**
     * @param mixed $etudiant
     */
    public function setEtudiant($etudiant)
    {
        $this->etudiant = $etudiant;
    }

    /**
     * @return \DateTime
     */
    public function getDateCreation()
    {
        return $this->dateCreation;
    }

    /**
     * @param \DateTime $dateCreation
     */
    public function setDateCreation($dateCreation)
    {
        $this->dateCreation = $dateCreation;
    }



    /**
     * @return string
     */


    /**
     * @inheritDoc
     */
    public function jsonSerialize()
    {
        return [
            "id" => $this->id,
            "id_reclamation" => $this->id_reclamation,
            //"id_send" => $this->id_send,
            "sujet" => $this->sujet,
            "message" => $this->message,
            "date" => $this->dateCreation->format("d-M-yy"),
            "etudiant" => $this->getEtudiant()
        ];
    }

    public function setDescription($get)
    {
    }
}

