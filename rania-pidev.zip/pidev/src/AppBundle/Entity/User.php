<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * User
 *
 * @ORM\Table(name="user")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\UserRepository")
 * @ORM\InheritanceType(value="JOINED")
 */
class User extends \FOS\UserBundle\Model\User implements \JsonSerializable
{
    const ROLE_ETUDIANT = 'ROLE_STUDENT';

    const ROLE_ENSEIGNANT = 'ROLE_ENS';

    public function __construct()
    {
        parent::__construct();
        $this->enabled = true;
        $this->addRole(User::ROLE_DEFAULT);
        $this->role = User::ROLE_DEFAULT;

        //$this->reclamations = new ArrayCollection();
    }


    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(name="role",type="string",length=255)
     */
    private $role;

    /**
     * @return mixed
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * @param mixed $role
     */
    public function setRole($role)
    {
        $this->role = $role;
    }


    /**
     * @inheritDoc
     */
    public function jsonSerialize()
    {
        return [
            "id" => $this->id
        ];
    }
}

