<?php

namespace ShopBundle\Controller;

use ShopBundle\Entity\Promotion;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PromotionController
 * @package ShopBundle\Controller
 * @Route(path="/promotion")
 */
class PromotionController extends Controller
{

    /**
     * @Route("/", name="promotion.list")
     * @param Request $request
     * @return Response|null
     */
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $promotions = $em->getRepository('ShopBundle:Promotion')->findAll();

        return $this->render('@Shop/back/promotion-list/index.html.twig', [
            'promotions' => $promotions
        ]);
    }

    /**
     * Delete Promotion.
     *
     * @Route("/remove/{id}", name="promotion.delete_id", methods={"POST"})
     */
    public function deleteAction(Request $request, Promotion $promotion)
    {

        $em = $this->getDoctrine()->getManager();
        $em->remove($promotion);
        $em->flush();
        $this->addFlash('success', 'Promotion successfully deleted.');

        return $this->redirectToRoute('promotion.list');
    }

    /**
     * Create Promotion.
     *
     * @Route("/create", name="promotion.create")
     */
    public function createAction(Request $request)
    {
        $promotion = new Promotion();
        $form = $this->createForm('ShopBundle\Form\PromotionType', $promotion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            return $this->redirectToRoute('promotion.list');
        }

        return $this->render('@Shop/back/promotion-edit/index.html.twig', [
            'promotion' => $promotion,
            'form' => $form->createView()
        ]);
    }

    /**
     * Edit Promotion.
     *
     * @Route("/edit/{id}", name="promotion.edit")
     */
    public function editAction(Request $request, Promotion $promotion)
    {
        $form = $this->createForm('ShopBundle\Form\PromotionType', $promotion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist($promotion);
            $em->flush();
            var_dump($promotion);

            return $this->redirectToRoute('promotion.list');
        }

        return $this->render('@Shop/back/promotion-edit/index.html.twig', [
            'promotion' => $promotion,
            'form' => $form->createView()
        ]);
    }
}
