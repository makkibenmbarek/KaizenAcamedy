<?php

namespace ShopBundle\Controller;

use Flosch\Bundle\StripeBundle\Stripe\StripeClient;
use ShopBundle\Form\CartType;
use ShopBundle\Utils\CartManager;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/cart")
 */
class CartController extends Controller
{

    /**
     * @var CartManager
     */
    private $cartManager;

    /**
     * @var StripeClient
     */
    public $stripeClient;

    /**
     * @return CartManager
     */
    public function getCartManager()
    {
        if ($this->cartManager === null)
            $this->cartManager = $this->get(CartManager::class);
        return $this->cartManager;
    }

    /**
     * @return StripeClient
     */
    public function getStripeClient()
    {
        if ($this->stripeClient === null)
            $this->stripeClient = $this->get('flosch.stripe.client');
        return $this->stripeClient;
    }

    /**
     * @Route("/", name="cart")
     * @param Request $request
     * @return Response|null
     */
    public function indexAction(Request $request)
    {
        $cart = $this->getCartManager()->getCart();
        //var_dump($cart->getItems());

        return $this->render('@Shop/cart/index.html.twig', [
            'cart' => $cart,
            //'count' => $cart->count()
        ]);
    }

    /**
     * @Route("/clear", name="cart_clear")
     * @return Response|null
     */
    public function clearAction()
    {
        $cart = $this->getCartManager()->getCart();
        $cart->clear();

        return $this->redirect('/shop/cart');
    }

    /**
     * Checkout process of the cart
     * @Route("/checkout", name="cart_checkout")
     * @return Response|null
     */
    public function checkoutAction()
    {

        $cart = $this->getCartManager()->getCart();


        $cartItems = $cart->getItems();
        $cartTotal = $cart->getDiscountTotal();
        $discount = $cart->getAppliedDiscount();

        //$this->getStripeClient()->createCharge($cartTotal, 'EUR', null);

        $this->addFlash('success', 'Checkout completed. Your order will be shipped soon.');
        $cart->clear();

        return $this->render('@Shop/invoice/index.html.twig', [
            'cart_items' => $cartItems,
            'total' => $cartTotal,
            'discount' => $discount,
            'orderId' => 0,
        ]);
    }
}
