<?php

namespace ShopBundle\Controller;

use ShopBundle\Entity\Formation;
use ShopBundle\Form\AchatType;
use ShopBundle\Utils\CartManager;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class FormationController extends Controller
{
    /**
     * @var CartManager
     */
    private $cartManager;

    /**
     * @Route("/detail/{id}", name="formation.detail", methods={"GET", "POST"})
     * @param Formation $formation
     * @return \Symfony\Component\HttpFoundation\Response|null
     */
    public function listAction(Formation $formation, Request $request)
    {
        $form = $this->createForm(AchatType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $item = $form->getData();
            $this->getCartManager()->getCart()->addItem($formation);
            $this->addFlash('success', 'Formation added to cart successfully.');

            //return $this->redirectToRoute('formation.detail', ['id' => $formation->getId()]);
        }

        return $this->render('@Shop/formation/detail.html.twig', [
            'formation' => $formation,
            'form' => $form->createView()
        ]);
    }

    /**
     * @return CartManager
     */
    public function getCartManager()
    {
        if ($this->cartManager === null)
            $this->cartManager = $this->get(CartManager::class);
        return $this->cartManager;
    }
}
