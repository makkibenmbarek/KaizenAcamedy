<?php

namespace ShopBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Routing\Annotation\Route;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="home")
     */
    public function indexAction()
    {

        $em = $this->getDoctrine()->getManager();
        $formations = $em->getRepository('ShopBundle:Formation')->findAll();

        return $this->render('ShopBundle:home:index.html.twig', [
            'formations' => $formations
        ]);
    }
}
