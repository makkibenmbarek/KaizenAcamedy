<?php


namespace ShopBundle\Utils;


class CartManagerStaticFactory
{

    public static function createCartManager()
    {
        return new CartManager();
    }


}